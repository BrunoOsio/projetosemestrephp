<head>

<style>
    .navbar {
        background-color: #CCC;
        height: 40px;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        align-content: center;
        gap: 10px;
        margin-bottom: 20px;
    }

    .navbar span{
        color: white;
        text-decoration: none;
    }
</style>

</head>

<div class="navbar">
    <span>
        <a href="/projetosemestre/cadastrarfuncionario/cadastrarfuncionario.php">Cadastrar Funcionário</a>
    </span>
    <span>
        <a href="/projetosemestre/cadastrarprojeto/cadastrarprojeto.php">Cadastrar projeto</a>
    </span>
    <span>
        <a href="/projetosemestre/listafuncionarios/listafuncionarios.php">Lista de funcionários</a>
    </span>
</div>
